# POO - Atividade - Atividade de Exceções: Parte 2

# Respostas:

## 1. Quando deve-se criar uma exceção personalizada? Explique.
Quando puder ocorrer alguma situação inesperada dentro do código e não existir uma exceção pronta que represente-a especificamente. 

## 2. Explique as consequências que o uso de exceções têm em construtores e métodos sobrescritos em uma hierarquia de herança.
As exceções adicinam certa complexidade á herança devido ao mecanismo de construção e a sobrescrita de métodos.

## 3. 
[Código implementado](https://github.com/deboradls/POO/tree/f2fd39aff9450ff709682bebdfceac80fd810636/AtividadeExcecoes/parte2/questao3)