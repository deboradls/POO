public class Bicicleta extends TransporteTerrestre implements Conduzivel{
    private int numeroRaios;

    @Override
    public boolean estaParado() {
        return super.estaParado();
    }

    public void curvar(float angulo){

    }
    public void pedalar(){

    }
}
