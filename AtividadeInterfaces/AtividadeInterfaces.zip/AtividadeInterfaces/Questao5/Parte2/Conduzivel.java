public interface Conduzivel {
    void curvar(float angulo);
}
