public class Bicicleta extends TransporteTerrestre implements Motorizado{
    private int numeroRaios;


    @Override
    public void abastecer(int numLitros) {
        
    }

    @Override
    public void ligarMotor() {
        
    }
    @Override
    public boolean estaParado() {
        return super.estaParado();
    }

    public void curvar(float angulo){

    }
    public void pedalar(){

    }

    
}
