public interface Motorizado {
    void ligarMotor();
    void abastecer(int numLitros);
}
