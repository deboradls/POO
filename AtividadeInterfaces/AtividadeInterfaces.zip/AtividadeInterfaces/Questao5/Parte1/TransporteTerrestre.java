public abstract class TransporteTerrestre extends Transporte{
    private String tipo;

    public void estacionar(){
        
    }
}
