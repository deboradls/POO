# POO - Atividade - Pacotes

# Respostas:

## 1. O que é um pacote na linguagem Java? Qual sua utilidade?
Um pacote representa uma ferramenta pela qual podemos organizar classes de acordo com seu contexto. É útil para separar classes de modo a permitir classes de mesmo nome, desde que estejam em pacotes diferentes.
 
## 2. Em quais situações o uso do import é necessário? Explique.
Quando a classe não está no mesmo diretório. Automaticamente, o java busca pela classe no mesmo diretório, para especificar de onde é a classe que desejamos usar é necessário o uso do import.

## 3. Crie um código-fonte na linguagem Java com as seguintes especificações
[Código implementado](https://github.com/deboradls/POO/tree/20adfd3cf8878364030b65ca1a32b8a0a12ffc08/AtividadePacotes/Questao3)
